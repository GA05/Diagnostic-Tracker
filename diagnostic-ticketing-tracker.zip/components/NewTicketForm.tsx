
import React, { useState } from 'react';
import { createTicketFromText, ParsedTicket } from '../services/geminiService';
import { SparklesIcon, LoadingIcon } from './icons/Icons';

interface NewTicketFormProps {
  addTicket: (newTicketData: ParsedTicket) => void;
}

const NewTicketForm: React.FC<NewTicketFormProps> = ({ addTicket }) => {
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) {
      setError("Please describe the issue.");
      return;
    }
    
    if (!process.env.API_KEY) {
        setError("API_KEY is not configured. Cannot create ticket.");
        return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const parsedTicket = await createTicketFromText(inputValue);
      addTicket(parsedTicket);
      setInputValue('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-800 p-4 rounded-lg shadow-md">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-start gap-3">
        <div className="w-full">
            <label htmlFor="ticket-input" className="sr-only">New Ticket Description</label>
            <input
            id="ticket-input"
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Describe a new ticket... e.g., 'The login page is down, this is critical!'"
            className="w-full bg-gray-800 border border-gray-700 rounded-md px-4 py-2 text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
            disabled={isLoading}
            />
        </div>
        <button
          type="submit"
          className="w-full sm:w-auto flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold px-4 py-2 rounded-md hover:bg-indigo-500 transition-all duration-200 disabled:bg-indigo-800 disabled:cursor-not-allowed"
          disabled={isLoading || !inputValue.trim()}
        >
          {isLoading ? <LoadingIcon /> : <SparklesIcon />}
          <span>{isLoading ? 'Creating...' : 'Create with AI'}</span>
        </button>
      </form>
      {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
    </div>
  );
};

export default NewTicketForm;
