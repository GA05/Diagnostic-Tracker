
import React from 'react';
import { Ticket, Status } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CheckCircleIcon, ClockIcon, DocumentPlusIcon, FolderIcon } from './icons/Icons';

interface DashboardProps {
  tickets: Ticket[];
}

const MetricCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode }> = ({ title, value, icon }) => (
  <div className="bg-gray-900 border border-gray-800 rounded-lg p-6 flex items-center gap-6">
    <div className="bg-gray-800 p-3 rounded-full">
        {icon}
    </div>
    <div>
      <p className="text-sm font-medium text-gray-400">{title}</p>
      <p className="text-3xl font-bold text-white">{value}</p>
    </div>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ tickets }) => {
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const newThisWeek = tickets.filter(t => t.createdAt >= oneWeekAgo).length;
  const resolvedThisWeek = tickets.filter(t => t.resolvedAt && t.resolvedAt >= oneWeekAgo).length;
  
  const resolvedTicketsWithTime = tickets
    .filter(t => t.status === Status.Resolved || t.status === Status.Closed)
    .filter(t => t.resolvedAt)
    .map(t => ({...t, resolutionTime: (t.resolvedAt!.getTime() - t.createdAt.getTime()) / (1000 * 3600) })); // in hours
  
  const avgResolutionHours = resolvedTicketsWithTime.length > 0
    ? resolvedTicketsWithTime.reduce((acc, t) => acc + t.resolutionTime, 0) / resolvedTicketsWithTime.length
    : 0;
  
  const formatAvgTime = (hours: number) => {
      if (hours < 24) return `${hours.toFixed(1)}h`;
      return `${(hours / 24).toFixed(1)}d`;
  }
  
  const openTickets = tickets.filter(t => t.status === Status.Open || t.status === Status.InProgress).length;

  const dailyData = Array.from({ length: 7 }).map((_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayStr = date.toLocaleDateString('en-US', { weekday: 'short' });

      const created = tickets.filter(t => t.createdAt.toDateString() === date.toDateString()).length;
      const resolved = tickets.filter(t => t.resolvedAt && t.resolvedAt.toDateString() === date.toDateString()).length;
      
      return { name: dayStr, created, resolved };
  }).reverse();

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title="New Tickets (7d)" value={newThisWeek} icon={<DocumentPlusIcon />} />
        <MetricCard title="Resolved Tickets (7d)" value={resolvedThisWeek} icon={<CheckCircleIcon color="text-green-400"/>} />
        <MetricCard title="Avg. Resolution Time" value={formatAvgTime(avgResolutionHours)} icon={<ClockIcon color="text-yellow-400"/>} />
        <MetricCard title="Total Open Tickets" value={openTickets} icon={<FolderIcon color="text-purple-400" />} />
      </div>
      
      <div className="bg-gray-900 border border-gray-800 rounded-lg p-6 shadow-lg">
         <h3 className="text-lg font-semibold text-white mb-4">Weekly Activity</h3>
         <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
                <BarChart data={dailyData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false}/>
                <Tooltip 
                    contentStyle={{ 
                        backgroundColor: '#1f2937', 
                        border: '1px solid #374151',
                        borderRadius: '0.5rem'
                    }} 
                    labelStyle={{ color: '#f3f4f6' }}
                />
                <Legend wrapperStyle={{fontSize: "14px"}}/>
                <Bar dataKey="created" fill="#4f46e5" name="Created" radius={[4, 4, 0, 0]} />
                <Bar dataKey="resolved" fill="#22c55e" name="Resolved" radius={[4, 4, 0, 0]} />
                </BarChart>
            </ResponsiveContainer>
         </div>
      </div>

    </div>
  );
};

export default Dashboard;
