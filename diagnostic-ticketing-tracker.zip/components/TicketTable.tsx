
import React from 'react';
import { Ticket } from '../types';
import NewTicketForm from './NewTicketForm';
import TicketRow from './TicketRow';

interface TicketTableProps {
  tickets: Ticket[];
  addTicket: (newTicketData: Omit<Ticket, 'id' | 'createdAt' | 'status'>) => void;
  updateTicket: (ticketId: string, updates: Partial<Ticket>) => void;
  deleteTicket: (ticketId: string) => void;
}

const TicketTable: React.FC<TicketTableProps> = ({ tickets, addTicket, updateTicket, deleteTicket }) => {
  return (
    <div className="space-y-6">
      <NewTicketForm addTicket={addTicket} />
      <div className="bg-gray-900/50 border border-gray-800 rounded-lg overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-800">
            <thead className="bg-gray-900">
              <tr>
                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-300 sm:pl-6">ID</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-300" style={{width: '40%'}}>Issue Description</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-300">Assignee</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-300">Status</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-300">Priority</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-300">Created</th>
                <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800 bg-gray-900">
              {tickets.map(ticket => (
                <TicketRow key={ticket.id} ticket={ticket} updateTicket={updateTicket} deleteTicket={deleteTicket} />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TicketTable;
