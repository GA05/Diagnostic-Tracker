
import React from 'react';
import { Ticket, Status, Priority } from '../types';
import { STATUS_OPTIONS, PRIORITY_OPTIONS, STATUS_COLORS, PRIORITY_COLORS } from '../constants';
import { TrashIcon, CheckCircleIcon } from './icons/Icons';

interface TicketRowProps {
  ticket: Ticket;
  updateTicket: (ticketId: string, updates: Partial<Ticket>) => void;
  deleteTicket: (ticketId:string) => void;
}

const SelectCell = <T extends string,>({ value, options, onChange, colorMap }: { value: T, options: T[], onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, colorMap: Record<T, string>}) => (
  <div className={`relative inline-block`}>
    <select
      value={value}
      onChange={onChange}
      className={`appearance-none w-full py-1 pl-2 pr-7 text-sm rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-transparent ${colorMap[value]}`}
    >
      {options.map(option => (
        <option key={option} value={option} className="bg-gray-800 text-white">
          {option}
        </option>
      ))}
    </select>
    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-1 text-gray-400">
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4"></path></svg>
    </div>
  </div>
);

const TicketRow: React.FC<TicketRowProps> = ({ ticket, updateTicket, deleteTicket }) => {
  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateTicket(ticket.id, { status: e.target.value as Status });
  };

  const handlePriorityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateTicket(ticket.id, { priority: e.target.value as Priority });
  };

  const handleCloseTicket = () => {
    updateTicket(ticket.id, { status: Status.Closed });
  }

  const timeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m ago";
    return Math.floor(seconds) + "s ago";
  };


  return (
    <tr className="hover:bg-gray-800/50 transition-colors">
      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-400 sm:pl-6">{ticket.id}</td>
      <td className="whitespace-normal py-4 px-3 text-sm text-gray-300 break-words">{ticket.description}</td>
      <td className="whitespace-nowrap py-4 px-3 text-sm text-gray-400">{ticket.assignee}</td>
      <td className="whitespace-nowrap py-4 px-3 text-sm">
         <SelectCell value={ticket.status} options={STATUS_OPTIONS} onChange={handleStatusChange} colorMap={STATUS_COLORS} />
      </td>
      <td className="whitespace-nowrap py-4 px-3 text-sm">
        <SelectCell value={ticket.priority} options={PRIORITY_OPTIONS} onChange={handlePriorityChange} colorMap={PRIORITY_COLORS} />
      </td>
      <td className="whitespace-nowrap py-4 px-3 text-sm text-gray-500">{timeAgo(ticket.createdAt)}</td>
      <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
        <div className="flex items-center justify-end gap-2">
           {ticket.status === Status.Resolved && (
            <button onClick={handleCloseTicket} className="text-green-400 hover:text-green-300 transition-colors" title="Auto-close ticket">
              <CheckCircleIcon />
            </button>
          )}
          <button onClick={() => deleteTicket(ticket.id)} className="text-gray-500 hover:text-red-400 transition-colors" title="Delete Ticket">
            <TrashIcon />
          </button>
        </div>
      </td>
    </tr>
  );
};

export default TicketRow;
