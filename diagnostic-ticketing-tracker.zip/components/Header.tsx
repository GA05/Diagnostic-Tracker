
import React from 'react';
import { View } from '../types';
import { ChartBarIcon, ListBulletIcon, LogoIcon } from './icons/Icons';

interface HeaderProps {
  currentView: View;
  setView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  const NavButton = ({ view, children }: { view: View; children: React.ReactNode }) => (
    <button
      onClick={() => setView(view)}
      className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
        currentView === view
          ? 'bg-gray-700 text-white'
          : 'text-gray-400 hover:bg-gray-800 hover:text-white'
      }`}
    >
      {children}
    </button>
  );

  return (
    <header className="bg-gray-950/80 backdrop-blur-sm sticky top-0 z-10 border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4">
            <div className="flex-shrink-0 text-white flex items-center gap-2">
              <LogoIcon />
              <span className="font-bold text-xl">Diagnostic Tracker</span>
            </div>
          </div>
          <nav className="flex items-center gap-2 p-1 bg-gray-900 rounded-lg">
            <NavButton view="tracker">
              <ListBulletIcon />
              Tracker
            </NavButton>
            <NavButton view="dashboard">
              <ChartBarIcon />
              Dashboard
            </NavButton>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
