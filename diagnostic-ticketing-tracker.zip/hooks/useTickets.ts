
import { useState } from 'react';
import { Ticket, Status, Priority } from '../types';

const initialTickets: Ticket[] = [
  {
    id: 'TICK-001',
    description: "User cannot log in with valid credentials.",
    assignee: 'Backend Team',
    status: Status.InProgress,
    priority: Priority.High,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
  },
  {
    id: 'TICK-002',
    description: "The main dashboard is loading slowly after the last update.",
    assignee: 'DevOps',
    status: Status.Open,
    priority: Priority.Medium,
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
  },
  {
    id: 'TICK-003',
    description: "Export to CSV feature is failing with a 500 error.",
    assignee: 'Backend Team',
    status: Status.Resolved,
    priority: Priority.Critical,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    resolvedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
  },
   {
    id: 'TICK-004',
    description: "UI text is misaligned on the settings page in Firefox.",
    assignee: 'Frontend Team',
    status: Status.Closed,
    priority: Priority.Low,
    createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    resolvedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
  },
];


export const useTickets = () => {
  const [tickets, setTickets] = useState<Ticket[]>(initialTickets);

  const addTicket = (newTicketData: Omit<Ticket, 'id' | 'createdAt' | 'status'>) => {
    const newTicket: Ticket = {
      ...newTicketData,
      id: `TICK-${String(tickets.length + 1).padStart(3, '0')}`,
      createdAt: new Date(),
      status: Status.Open,
    };
    setTickets(prevTickets => [newTicket, ...prevTickets]);
  };

  const updateTicket = (ticketId: string, updates: Partial<Omit<Ticket, 'id' | 'createdAt'>>) => {
    setTickets(prevTickets =>
      prevTickets.map(ticket => {
        if (ticket.id === ticketId) {
          const wasResolved = ticket.status !== Status.Resolved && updates.status === Status.Resolved;
          return { 
            ...ticket, 
            ...updates,
            resolvedAt: wasResolved ? new Date() : (updates.status !== Status.Resolved ? undefined : ticket.resolvedAt)
          };
        }
        return ticket;
      })
    );
  };

  const deleteTicket = (ticketId: string) => {
    setTickets(prevTickets => prevTickets.filter(ticket => ticket.id !== ticketId));
  };

  return { tickets, addTicket, updateTicket, deleteTicket };
};
