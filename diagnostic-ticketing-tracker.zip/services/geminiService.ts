
import { GoogleGenAI } from "@google/genai";
import { Priority } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export interface ParsedTicket {
    description: string;
    priority: Priority;
    assignee: string;
}

export const createTicketFromText = async (userInput: string): Promise<ParsedTicket> => {
    const prompt = `
        You are an intelligent assistant that processes support ticket requests for a software company.
        Analyze the user's text and extract the ticket details.
        Respond ONLY with a valid JSON object. Do not include any other text, explanations, or markdown fences like \`\`\`json.

        The JSON object must have the following structure:
        {
          "description": "A detailed description of the issue.",
          "priority": "The priority of the ticket.",
          "assignee": "The name of the person or team assigned to the ticket."
        }

        Valid values for the "priority" field are: "Low", "Medium", "High", "Critical".
        - Infer "Critical" from keywords like 'urgent', 'asap', 'critical', 'blocker', 'down', 'outage'.
        - Infer "High" from keywords like 'important', 'high priority', 'major issue'.
        - Infer "Low" from keywords like 'low priority', 'cosmetic', 'sometime this week', 'minor'.
        - If no strong keywords are found, default to "Medium".

        Valid values for the "assignee" field are: "Frontend Team", "Backend Team", "DBA", or "DevOps".
        - Infer "Frontend Team" for UI issues, visual bugs, interactivity problems (e.g., 'button not working', 'text is misaligned').
        - Infer "Backend Team" for API errors, server logic, data processing issues (e.g., '500 error', 'login fails').
        - Infer "DBA" for database-related problems (e.g., 'query is slow', 'database connection error').
        - Infer "DevOps" for infrastructure, deployment, or performance issues (e.g., 'server is slow', 'deployment failed', 'scaling issue').
        - If unsure, assign to the most likely team based on the description.

        User input: "${userInput}"
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
            },
        });
        
        const jsonText = response.text.trim();
        const parsedData = JSON.parse(jsonText) as ParsedTicket;

        // Validate parsed data
        if (!parsedData.description || !parsedData.priority || !parsedData.assignee) {
            throw new Error("Parsed data is missing required fields.");
        }

        return parsedData;

    } catch (error) {
        console.error("Error processing ticket with Gemini:", error);
        throw new Error("Failed to create ticket. The AI service may be unavailable or the request was invalid.");
    }
};
